<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Cadastro</title>
<link rel="stylesheet" href="teste.css">
</head>
<body>

<div class="container">
    <img src="mot.png">
<form name="signup" method="post" action="home">
<div class="form-input">
    <input type="text" name="nome" placeholder="Nome"/> <br/> <br/>
</div>
    <div class="form-input">
    <input type="text" name="datanasc" placeholder="Data de Nascimento"/> <br/> <br/>
</div>
    <div class="form-input">
    <input type="text" name="cpf" placeholder="CPF"/> <br/> <br/>
</div>
    <div class="form-input">
    <input type="text" name="modelocarro" placeholder="Modelo do Carro"/> <br/> <br/>
</div>
    <div class="form-input">
    <input type="text" name="status" placeholder="Status"/> <br/> <br/>
</div>
    <div class="form-input">
    <input type="text" name="sexo" placeholder="Sexo"/> <br/> <br/>
</div>
<div class="form-input">
    <input type="password" name="senha" placeholder="Cadastre uma senha"/> <br/> <br/>
</div>

<input type="submit" name="submit" value="Cadastrar" class="btn-login"/>
</form>
</div>
</body>
</html>