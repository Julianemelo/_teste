<?php
if(!isset($_SESSION['logado'])){
    header('Location: home');
}
?>